--[[
	原理：
		利用 Lua 的垃圾回收机制实现
		建立一个不会用到的表型全局变量，将其 __gc 元方法设为一个函数
		当 Lua 虚拟机结束之时，这个表的 __gc 元方法就会触发
--]]

function atexit(callback) -- 这个函数可以直接拷贝到你的脚本中使用
	____atexit_guard____ = ____atexit_guard____ or {}
	if type(____atexit_guard____) == 'table' then
		if not getmetatable(____atexit_guard____) then
			setmetatable(____atexit_guard____, {
				__gc = function(self)
					if type(self.callback) == 'function' then
						pcall(self.callback)
					end
				end
			})
		end
		____atexit_guard____.callback = callback
	else
		error('别用 `____atexit_guard____` 命名你的变量。')
	end
end

-- 使用 atexit 注册一个终止回调函数
atexit(function() 
	sys.toast('被终止了！')
	sys.msleep(500)
end)

local spawn_args = json.decode(proc_get("spawn_args"))
if type(spawn_args)~="table" then
	spawn_args = {}
end
spawn_args.ip = type(spawn_args.ip)=="string" and spawn_args.ip or "未知来源"

while (true) do
	sys.toast("脚本从 ["..spawn_args.ip.."] 启动\n\n现在可尝试手动结束脚本\n\n开发讨论QQ群：40898074\n未得原作者许可，可以用于商业用途！\n"..os.date("%Y-%m-%d %H:%M:%S"))
	sys.msleep(1000)
end